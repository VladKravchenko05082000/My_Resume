$(document).ready(function () {
   $('.header__burger').click(function (event) {
      $('.header__burger, .header__menu').toggleClass('active');
   });
   $('.header__menu__item').click(function (event) {
      $('.header__burger, .header__menu').removeClass('active');
   });

});